// ...existing code...
void TestComputer( struct Board * argsBoard,
                   struct GeneralMove * argsGeneralMoves )
{

// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
   SetStopGo( dGo );
   int iScore = StartSearch( argsBoard,
                             argsGeneralMoves,
                             dAlpha,
                             dBeta );

   cout << "Score = " << iScore << endl;
   cout << "Number of nodes searched = " << (long long)GetNumberOfNodes() << endl;

   // Print the principal variation
   PrintPrincipalVariation( argsBoard,
// ...existing code...
